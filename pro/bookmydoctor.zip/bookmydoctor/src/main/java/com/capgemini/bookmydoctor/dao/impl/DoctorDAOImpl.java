package com.capgemini.bookmydoctor.dao.impl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.bookmydoctor.dao.DoctorDAO;
import com.capgemini.bookmydoctor.dto.AppointmentInfo;
import com.capgemini.bookmydoctor.dto.DoctorAvailabilityInfo;
import com.capgemini.bookmydoctor.dto.DoctorInfo;

public class DoctorDAOImpl implements DoctorDAO {

	@Override
	public void addDoctorInfo(DoctorInfo doctorInfo) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("doctoraddquery"));) {

				pstmt.setInt(1, doctorInfo.getDoctorId());
				pstmt.setString(2, doctorInfo.getDoctorName());
				pstmt.setString(3, doctorInfo.getSpeciality());
				pstmt.setString(4, doctorInfo.getLocation());
				pstmt.setString(5, doctorInfo.getAddress());
				pstmt.setLong(6, doctorInfo.getVisitingFee());
				pstmt.setInt(7, doctorInfo.getUserId());

				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}

	}

	@Override
	public void updateDoctorInfo(int doctorId, DoctorInfo doctorInfo) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {

			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("doctorupdatequery"));) {
				pstmt.setString(1, doctorInfo.getLocation());
				pstmt.setString(2, doctorInfo.getAddress());
				pstmt.setLong(3, doctorInfo.getVisitingFee());
				pstmt.setInt(4, doctorId);
				pstmt.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		} catch (IOException e1) {

			e1.printStackTrace();
		}

	}

	@Override
	public AppointmentInfo viewAppointment(int id) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}
		AppointmentInfo appointmentInfo = null;

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("viewappointmentquery"));) {

				pstmt.setInt(1, id);

				try (ResultSet rs = pstmt.executeQuery();) {
					while (rs.next()) {
						appointmentInfo = new AppointmentInfo();
						appointmentInfo.setAppointmentId(rs.getInt("appointmentId"));
						appointmentInfo.setPatientId(rs.getInt("patientId"));
						appointmentInfo.setDoctorId(rs.getInt("doctorId"));
						appointmentInfo.setDate(rs.getDate("date"));
						appointmentInfo.setTime(rs.getTime("time"));
						appointmentInfo.setStatus(rs.getString("status"));

					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (SQLException e1) {

				e1.printStackTrace();
			}

		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		} catch (IOException e1) {

			e1.printStackTrace();
		}

		return appointmentInfo;

	}

	@Override
	public void acceptAppointment(int id) {

		// AppointmentInfo appointmentInfo = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("appectappointmentquery"));) {
				pstmt.setString(1, "Accepted");
				pstmt.setInt(2, id);

				pstmt.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		} catch (IOException e1) {

			e1.printStackTrace();
		}

	}

	@Override
	public void rejectAppointment(int id) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("rejectappointmentquery"));) {
				pstmt.setString(1, "Rejected");
				pstmt.setInt(2, id);

				pstmt.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		} catch (IOException e1) {

			e1.printStackTrace();
		}

	}

	@Override
	public void updateAvailabity(DoctorAvailabilityInfo doctorAvailabilityInfo, int id) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection
							.prepareStatement(pro.getProperty("updateavailabilityquery"));) {
				pstmt.setDate(1, doctorAvailabilityInfo.getFromDate());
				pstmt.setDate(2, doctorAvailabilityInfo.getToDate());
				pstmt.setString(3, doctorAvailabilityInfo.getIsAvialable());
				pstmt.setInt(4, id);

				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}

	}

	@Override
	public void addDoctorAvailability(DoctorAvailabilityInfo doctorAvailabilityInfo) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection
							.prepareStatement(pro.getProperty("adddoctoravailibityquery"));) {
				pstmt.setInt(1, doctorAvailabilityInfo.getDoctorId());
				pstmt.setTime(2, doctorAvailabilityInfo.getFromTime());
				pstmt.setTime(3, doctorAvailabilityInfo.getToTime());
				pstmt.setString(4, doctorAvailabilityInfo.getIsAvialable());

				pstmt.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		} catch (IOException e1) {

			e1.printStackTrace();
		}

	}

}
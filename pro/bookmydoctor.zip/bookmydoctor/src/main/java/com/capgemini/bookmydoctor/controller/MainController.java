package com.capgemini.bookmydoctor.controller;

import java.util.Scanner;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class MainController {

	static Scanner sc = new Scanner(System.in);

	static Logger log = LogManager.getLogger("user");

	public static void user() {
		while (true) {
			log.info("----------------------------------------");
			log.info("WELCOME TO BOOK MY DOCTOR APPLICATION");
			log.info("Press 1.Admin\nPress 2.Doctor\nPress 3.Patient\nPress 4.Exit");
			log.info("----------------------------------------");
			log.info("Enter your choice");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:

				break;

			case 2:
				DoctorController doctorController = new DoctorController();
				doctorController.enterChoice();
				break;

			case 3:

				break;

			case 4:
				System.exit(0);

			default:
				log.info("Invalid Choice");

			}
		}

	}

	public static void main(String[] args) {

		while (true) {
			log.info("----------------------------------------");
			log.info("WELCOME TO BOOK MY DOCTOR APPLICATION");
			log.info("Press 1.Admin\nPress 2.Doctor\nPress 3.Patient\nPress 4.Home\nPress 5.Exit");
			log.info("----------------------------------------");
			log.info("Enter your choice");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:

				break;

			case 2:
				DoctorController doctorController = new DoctorController();
				doctorController.enterChoice();
				break;

			case 3:
				break;
			case 4:
				user();
				break;
			case 5:
				System.exit(0);

			default:
				log.info("Invalid Choice");

			}

		}

	}
}

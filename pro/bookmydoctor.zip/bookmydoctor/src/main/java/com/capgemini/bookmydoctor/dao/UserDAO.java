package com.capgemini.bookmydoctor.dao;

import com.capgemini.bookmydoctor.dto.UserInfo;

public interface UserDAO {
	
	public void insertUser( UserInfo userInfo);
	
	public void updateUser(String password, int userId);
	
	public UserInfo getUser(int id);
	
	public UserInfo getAllUser();
	
	
	
}

package com.capgemini.bookmydoctor.dto;

import lombok.Data;

@Data
public class DoctorInfo {
	
	private int doctorId;
	private String doctorName;
	private String speciality;
	private String location;
	private String address;
	private long visitingFee;
	private int userId;
	
	
}

package com.capgemini.bookmydoctor.dao;

import com.capgemini.bookmydoctor.dto.AppointmentInfo;
import com.capgemini.bookmydoctor.dto.DoctorAvailabilityInfo;
import com.capgemini.bookmydoctor.dto.DoctorInfo;

public interface DoctorDAO {

	public void addDoctorInfo(DoctorInfo doctorInfo);

	public void updateDoctorInfo(int doctorId, DoctorInfo doctorInfo);

	public AppointmentInfo viewAppointment(int id);

	public void acceptAppointment(int id);

	public void rejectAppointment(int id);

	public void addDoctorAvailability(DoctorAvailabilityInfo doctorAvailabilityInfo);

	public void updateAvailabity(DoctorAvailabilityInfo doctorAvailabilityInfo, int id);
}

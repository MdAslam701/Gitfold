 package com.capgemini.bookmydoctor.service;

import com.capgemini.bookmydoctor.dto.UserInfo;

public interface UserService {
	
	public void addUser(UserInfo userInfo);
	
	public void updateUser(String password, int userId);
	
	public UserInfo getUser(int id);
	
	public UserInfo getAllUser();

}

package com.capgemini.bookmydoctor.factory;


import com.capgemini.bookmydoctor.exception.BookMyDoctorException;
import com.capgemini.bookmydoctor.service.DoctorService;
import com.capgemini.bookmydoctor.service.UserService;
import com.capgemini.bookmydoctor.service.impl.DoctorSerImpl;
import com.capgemini.bookmydoctor.service.impl.UserSerImpl;
import com.capgemini.bookmydoctor.validate.ValidateBookMyDoctor;
import com.capgemini.bookmydoctor.validate.ValidateBookMyDoctorImpl;

public class UserFactory {
	
	public UserService getUserObj() {
		UserService userService = new UserSerImpl();
		return userService;
		
	}
	
	public DoctorService getDoctorObj() {
		DoctorService doctorService = new DoctorSerImpl();
		return doctorService;
	}
	
	public ValidateBookMyDoctor getValidateMethods() {
		ValidateBookMyDoctor validateBookMyDoctor = new ValidateBookMyDoctorImpl();
		return validateBookMyDoctor;
	}
		
}

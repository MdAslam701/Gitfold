package com.capgemini.util;

import java.util.Scanner;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordValidator {
	public static boolean passwordValidator(String plainPassword, String hashPassword) {
	return	BCrypt.checkpw(plainPassword, hashPassword);

	}
	public static void main(String[] args) {
		Scanner sc  = new Scanner(System.in);
		System.out.println("Enter the password to be encoded");
		String plainPassword = sc.nextLine();
		String hashPassword = PasswordEncoder.passwordEncoder(plainPassword);
		System.out.println(hashPassword);
		System.out.println("Enter the password to matches");
		String Passord = sc.nextLine(); 
		//passwordValidator(plainPassword, hashPassword);
		if(passwordValidator(Passord, hashPassword)) {
			System.out.println("password MAtchs");
		} else {
			System.out.println("invalid");
		}
		sc.close();
	}
}

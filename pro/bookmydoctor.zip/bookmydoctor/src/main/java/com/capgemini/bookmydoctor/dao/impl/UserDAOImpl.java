package com.capgemini.bookmydoctor.dao.impl;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.capgemini.bookmydoctor.dao.UserDAO;
import com.capgemini.bookmydoctor.dto.UserInfo;

public class UserDAOImpl implements UserDAO {

	// to insert
	public void insertUser(UserInfo userInfo) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("insertuserquery"));) {

				pstmt.setString(1, userInfo.getUserType());
				pstmt.setString(2, userInfo.getPassword());
				pstmt.setLong(3, userInfo.getPrimaryPhoneNo());
				pstmt.setString(4, userInfo.getEmailId());
				pstmt.setString(5, userInfo.getGender());
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// code to update
	@Override
	public void updateUser(String password, int userId) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("updateuserquery"));) {
				pstmt.setString(1, password);
				pstmt.setInt(2, userId);

				pstmt.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// code to get user
	@Override
	public UserInfo getUser(int id) {

		UserInfo userInfo = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("getuserquery"));) {
				pstmt.setInt(1, id);
				try (ResultSet rs = pstmt.executeQuery();) {
					while (rs.next()) {
						userInfo = new UserInfo();

						userInfo.setUserId(rs.getInt("userId"));
						userInfo.setPassword(rs.getString("password"));
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return userInfo;
	}

	@Override
	public UserInfo getAllUser() {
		UserInfo userInfo = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}

		try (FileInputStream file = new FileInputStream("C:\\Users\\User\\Desktop\\Book My Doctor Project\\"
				+ "bookmydoctor\\src\\main\\java\\db.properties");) {
			Properties pro = new Properties();
			pro.load(file);
			try (Connection connection = DriverManager.getConnection(pro.getProperty("dburl"));
					PreparedStatement pstmt = connection.prepareStatement(pro.getProperty("getalluserquery"));) {
				try (ResultSet rs = pstmt.executeQuery();) {
					while (rs.next()) {
						userInfo = new UserInfo();

						userInfo.setUserId(rs.getInt("userId"));
						userInfo.setUserType(rs.getString("userType"));
						userInfo.setPassword(rs.getString("password"));
						userInfo.setPrimaryPhoneNo(rs.getLong("primaryPhoneNO"));
						userInfo.setEmailId(rs.getString("emailId"));
						userInfo.setGender(rs.getString("gender"));
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return userInfo;

	}

}

package com.capgemini.bookmydoctor.dao;

public interface AdminDao {

}

package com.capgemini.bookmydoctor.controller;

import java.util.Scanner;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.capgemini.bookmydoctor.dto.UserInfo;
import com.capgemini.bookmydoctor.exception.BookMyDoctorException;
import com.capgemini.bookmydoctor.factory.UserFactory;
import com.capgemini.bookmydoctor.service.UserService;
import com.capgemini.bookmydoctor.validate.ValidateBookMyDoctor;
import com.capgemini.bookmydoctor.validate.ValidateBookMyDoctorImpl;

public class UserController {
	
	ValidateBookMyDoctor validateBookMyDoctor = new ValidateBookMyDoctorImpl();

	Scanner sc = new Scanner(System.in);
	Logger log = LogManager.getLogger("user");
	UserInfo userInfo = new UserInfo();

	/*
	 * int choice = sc.nextInt();
	 * 
	 * public void userPage() {
	 * 
	 * log.info("1.LogIn\n2.SingUp");
	 * 
	 * switch (choice) { case 1: logIn(); break;
	 * 
	 * case 2: signUp(); break;
	 * 
	 * default: log.info("Enter Valid Choice"); break; }
	 * 
	 * }
	 */

	/*
	 * public void logIn() {
	 * 
	 * }
	 */
	public int signUp() {
		
		UserFactory userFactory = new UserFactory();
		ValidateBookMyDoctor validateMyDoctor = userFactory.getValidateMethods();
		ValidateController validateController = new ValidateController();

//		log.info("Enter User Id");
//		int userId = sc.nextInt();
//		userInfo.setUserId(userId);
		log.info("Enter user Type");
		String type = sc.next();
		sc.nextLine();
		userInfo.setUserType(type);

		log.info("Enter the password");
		String password = null;
		try {
			password = sc.next();
			validateMyDoctor.emailIdValidate(password);
		} catch (BookMyDoctorException e) {
			e.getMessage();
		}
		

		log.info("enter primary phone number");
		long phone = sc.nextLong();
		userInfo.setPrimaryPhoneNo(phone);

		log.info("Enter email id");
		String emailId = sc.next();
		validateBookMyDoctor.emailValidator(emailId);
//		sc.nextLine();
//		userInfo.setEmailId(emailId);

		log.info("Enter gender");
		String gender = sc.next();
		sc.nextLine();
		userInfo.setGender(gender);

		UserFactory userFactory1 = new UserFactory();
		UserService service1 = userFactory1.getUserObj();
		service1.addUser(userInfo);

		return userInfo.getUserId();

	}

	public void updateUser(int id) {
		String password = sc.next();
		sc.nextLine();

		UserFactory userFactory = new UserFactory();
		UserService service = userFactory.getUserObj();
		service.updateUser(password, id);

	}

}

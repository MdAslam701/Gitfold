package com.capgemini.bookmydoctor.exception;

public class ExceptionMethods {
	
	// Method to check email format is valid or not
		public static String emailValidator(String email) throws MedicalExceptions {
			String emailId = medicalValidations.emailIdValidate(email);
			if (emailId != null) {
				return emailId;
			} else {
				throw new MedicalExceptions("Enter the Email in format like abc@gmail.com");
			}
		}

}
//Method to check email format is valid or not
	public static String emailValidator(String email) throws MedicalExceptions {
		String emailId = medicalValidations.emailIdValidate(email);
		if (emailId != null) {
			return emailId;
		} else {
			throw new MedicalExceptions("Enter the Email in format like abc@gmail.com");
		}
	}
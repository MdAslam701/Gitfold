package com.capgemini.bookmydoctor.controller;

import com.capgemini.bookmydoctor.dto.UserInfo;
import com.capgemini.bookmydoctor.factory.UserFactory;
import com.capgemini.bookmydoctor.service.UserService;
import com.capgemini.bookmydoctor.validate.ValidateBookMyDoctor;

public class ValidateController {
	
	UserFactory userFactory = new UserFactory();
	
	
	static boolean validation = false;
	
	
	
	public void emailValidator(String emailId){
		UserService user = userFactory.getUserObj();
		user.getUser(id)
		ValidateBookMyDoctor validator = userFactory.getValidateMethods();
		String email = null;
		boolean check = false;
		validation = true;
		while(validation) {
			try {
				email= validator.emailIdValidate(emailId);
			      check    = userInfo.getEmailId();
				 
				if (emailId != null) {
					return emailId;
				} else {
					throw new MedicalExceptions("Enter the Email in format like abc@gmail.com");
				}
			}
		}
		
	}

}

System.out.println("Enter your Email: ");
String email = null;
boolean check = false;
validation = true;
while (validation) {
	try {
		emailId = scanner.nextLine();
		email = ExceptionMethods.emailValidator(emailId);
		check = ExceptionMethods.searchEmail(emailId);
		validation = false;
	} catch (MedicalExceptions e) {
		e.getMessage();
	}
}
info.setEmail(email);


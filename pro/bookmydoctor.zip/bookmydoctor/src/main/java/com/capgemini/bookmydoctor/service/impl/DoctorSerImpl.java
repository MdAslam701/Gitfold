package com.capgemini.bookmydoctor.service.impl;

import java.util.Date;

import com.capgemini.bookmydoctor.dao.DoctorDAO;
import com.capgemini.bookmydoctor.dao.impl.DoctorDAOImpl;
import com.capgemini.bookmydoctor.dto.AppointmentInfo;
import com.capgemini.bookmydoctor.dto.DoctorAvailabilityInfo;
import com.capgemini.bookmydoctor.dto.DoctorInfo;
import com.capgemini.bookmydoctor.service.DoctorService;

public class DoctorSerImpl implements DoctorService{
	DoctorDAO doctorDAO = new DoctorDAOImpl();

	@Override
	public void addDoctorInfo(DoctorInfo doctorInfo) {
		doctorDAO.addDoctorInfo(doctorInfo);
		
	}

	@Override
	public void updateDoctorInfo(int doctorId, DoctorInfo doctorInfo) {
	doctorDAO.updateDoctorInfo(doctorId, doctorInfo);
		
	}

	@Override
	public AppointmentInfo veiwAppointment(int doctorId) {
		AppointmentInfo appointmentInfo = doctorDAO.viewAppointment(doctorId);
		return appointmentInfo ;
	}

	@Override
	public void acceptAppointment(int id) {
		doctorDAO.acceptAppointment(id);
		
		
	}

	@Override
	public void rejectAppointment(int id) {
		doctorDAO.rejectAppointment(id);
		
	}
	
	@Override
	public void addDoctorAvailability(DoctorAvailabilityInfo doctorAvailabilityInfo) {
		doctorDAO.addDoctorAvailability(doctorAvailabilityInfo);
		
	}

	@Override
	public void updateAvailabity(DoctorAvailabilityInfo doctorAvailabilityInfo, int id) {
		doctorDAO.updateAvailabity(doctorAvailabilityInfo, id);
		
	}

	


	
	

}

package com.capgemini.bookmydoctor.service;

import com.capgemini.bookmydoctor.dto.AppointmentInfo;
import com.capgemini.bookmydoctor.dto.DoctorAvailabilityInfo;
import com.capgemini.bookmydoctor.dto.DoctorInfo;

public interface DoctorService {

	public void addDoctorInfo(DoctorInfo doctorInfo);

	public void updateDoctorInfo(int doctorId, DoctorInfo doctorInfo);

	public AppointmentInfo veiwAppointment(int doctorId);

	public void acceptAppointment(int id);

	public void rejectAppointment(int id);

	public void addDoctorAvailability(DoctorAvailabilityInfo doctorAvailabilityInfo);
	
	public void updateAvailabity(DoctorAvailabilityInfo doctorAvailabilityInfo, int id);

}

package com.capgemini.bookmydoctor.validate;

public interface ValidateBookMyDoctor {

	//public Integer validateNumber(String id);

	

	//public Double doubleValidate(String number);

	//public Long contactValidate(String contact);

	public String passwordValidate(String password);

	public String emailIdValidate(String emailId);

	//public String charValidate(String character);

	//public Long cardNumberValidator(String cardNumber);

	//public Integer monthValidate(String month);

	//public Integer yearValidate(String year);

	//public Integer checkCVV(String cvv);
	
	//public String nameValidate(String name);
	
}

package com.capgemini.bookmydoctor.dto;

import java.sql.Date;
import java.sql.Time;

import lombok.Data;

@Data
public class AppointmentInfo {

	private int appointmentId;
	private int patientId;
	private int doctorId;
	private Date date;
	private Time time;
	private String status;
	
}
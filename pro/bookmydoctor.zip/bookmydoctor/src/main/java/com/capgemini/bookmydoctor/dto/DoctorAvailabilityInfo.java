package com.capgemini.bookmydoctor.dto;

import java.sql.Date;
import java.sql.Time;

import lombok.Data;

@Data
public class DoctorAvailabilityInfo {
	
	private int doctorId;
	private Date fromDate;
	private Date toDate;
	private Time fromTime;
	private Time toTime;
	private String isAvialable; 
	

}

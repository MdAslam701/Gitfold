package com.capgemini.bookmydoctor.controller;

import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;

import javax.jws.soap.SOAPBinding.Use;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.capgemini.bookmydoctor.dto.AppointmentInfo;
import com.capgemini.bookmydoctor.dto.DoctorAvailabilityInfo;
import com.capgemini.bookmydoctor.dto.DoctorInfo;
import com.capgemini.bookmydoctor.dto.UserInfo;
import com.capgemini.bookmydoctor.factory.UserFactory;
import com.capgemini.bookmydoctor.service.DoctorService;
import com.capgemini.bookmydoctor.service.UserService;
import com.capgemini.bookmydoctor.validate.ValidateBookMyDoctor;
import com.capgemini.bookmydoctor.validate.ValidateBookMyDoctorImpl;


public class DoctorController {
	
	ValidateBookMyDoctor validateBookMyDoctor = new ValidateBookMyDoctorImpl();

	Logger log = LogManager.getLogger("user");

	Scanner sc = new Scanner(System.in);

//	 DoctorInfo doctorInfo = new DoctorInfo();
//	 UserInfo userInfo = new UserInfo();

	public void enterChoice() {
		log.info("----------------------------------------");
		log.info("Press 1.To LogIn\nIf new User Press\n2.To SignUp\nPress 3.Exit ");
		log.info("----------------------------------------");

		
		while (true) {
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				passwordRecovery();
				break;

			case 2:
				log.info("Enter Details");
				UserController userController = new UserController();
				int id = userController.signUp();
				doctorSingUp(id);
				break;
			
			case 3:
				System.exit(0);
			

			default:
				log.info("Invalid Entry");

			}

		}
	}

	public void passwordRecovery() {
		log.info("Press 1.logIN\nPress 2.recover your password");
	
		while (true) {
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				doctorLogIn();
				break;

			case 2:
				log.info("Enter ID to get Your password");
				int id = sc.nextInt();
				UserFactory userFactory = new UserFactory();
				UserService service = userFactory.getUserObj();
				UserInfo user = service.getUser(id);
				log.info("Your Password is "+user.getPassword());
				break;

			default:
				log.info("Invalid Entry");
				break;
			}
		}

	}

	public void doctorLogIn() {
		log.info("----------------------------------------");
		log.info("Welcome to login page");
		log.info("----------------------------------------");

		log.info("Enter the LogIN id");
		int id = sc.nextInt();
		UserFactory factory = new UserFactory();
		UserService service = factory.getUserObj();
		UserInfo user = service.getUser(id);

		log.info("Enter the password");
		
		String password = sc.next();
		
		sc.nextLine();
		if (id == user.getUserId() && password.equals(user.getPassword())) {
			while (true) {
				log.info("LOG IN SUCCESSFULL");
				log.info("----------------------------------------");
				log.info("Press 1.update password\nPress 2.Update Details");
				log.info("Press 3.View Appointment\nPress 4.Manage "
						+ "Appointment\nPress 5.update availability\nPress 6.Log Out");
				log.info("----------------------------------------");

				int choice = sc.nextInt();
				switch (choice) {

				case 1:
					// Update Password
					UserFactory userFactory = new UserFactory();
					UserService service1 = userFactory.getUserObj();
					log.info("Enter the new password");
					String pas = sc.next();
					service1.updateUser(pas, id);
					log.info("password updated");
					break;

				case 2:
					// update Deatils

					// ValidateDoctorInfoSignUp validateDoctorInfoSignUp = new
					// ValidateDoctorInfoSignUp();
					DoctorInfo doctorInfo = new DoctorInfo();

//					log.info("Enter your name");
//					String name = sc.next();
//					sc.nextLine();
//					if (validateDoctorInfoSignUp.validateName(name)) {
//						doctorInfo.setDoctorName(name);
//					} else {
//						// code to throw exception
//						System.out.println("throw");
//					}

					log.info("Enter	new Location");
					String location = sc.next();
					sc.nextLine();
					// if (validateDoctorInfoSignUp.validateLocation(location)) {
					doctorInfo.setLocation(location);
					// } else {
					// code to throw exception
				//	}

					log.info("Enter new Address");
					String address = sc.next();
					sc.nextLine();
					// if (validateDoctorInfoSignUp.validateAddress(address)) {
					doctorInfo.setAddress(address);
					// } else {
					// code to throw exception
					// }

					log.info("Enter	new Visiting Fee");
					long fee = sc.nextInt();
					// if (validateDoctorInfoSignUp.validateVisitingFee(fee)) {
					doctorInfo.setVisitingFee(fee);
					// } else {
					// code to throw exception
					// }
					UserFactory userFactory2 = new UserFactory();
					DoctorService service2 = userFactory2.getDoctorObj();
					service2.updateDoctorInfo(id, doctorInfo);
					break;

				case 3:
					// view Appointments
					log.info("Enter the id");
					int dId1 = sc.nextInt();
					UserFactory userFactory3 = new UserFactory();
					DoctorService service3 = userFactory3.getDoctorObj();
					AppointmentInfo appointments = service3.veiwAppointment(dId1);

					log.info(appointments);
					break;

				case 4:
					// Manage Appointments
					manageAppointment();
					break;

				case 5:
					// Manage Availability
					updateAvailability();
					break;

				case 6:
					// Main page
					MainController.user();
					break;

				default:
					log.info("invalid Entry");
				}
			}
		} else {
			System.out.println("Throw");
		}

	}

	public void doctorSingUp(int doctorId) {
		DoctorInfo doctorInfo = new DoctorInfo();
		// ValidateDoctorInfoSignUp validateDoctorInfoSignUp = new
		// ValidateDoctorInfoSignUp();

		// log = LogManager.getLogger(doctorInfo.getDoctorName());
		doctorInfo.setDoctorId(doctorId);
		log.info("Enter doctor name");
		String name = sc.next();
		sc.nextLine();
		// if (validateDoctorInfoSignUp.validateName(name)) {
		doctorInfo.setDoctorName(name);
		// } else {
		// code to throw exception
		// }

		log.info("Enter Speciality");
		String speciality = sc.next();
		sc.nextLine();
		// if (validateDoctorInfoSignUp.validateSpeciality(speciality)) {
		doctorInfo.setSpeciality(speciality);
		// } else {
		// code to throw exception
		// }
		log.info("Enter Location");
		String location = sc.next();
		sc.nextLine();
		// if (validateDoctorInfoSignUp.validateLocation(location)) {
		doctorInfo.setLocation(location);
		// } else {
		// code to throw exception
		// }

		log.info("Enter Address");
		String address = sc.next();
		sc.nextLine();
		// if (validateDoctorInfoSignUp.validateAddress(address)) {
		doctorInfo.setAddress(address);
		// } else {
		// code to throw exception
		// }

		log.info("Enter Visiting Fee in Rs format\nEx: 2000");
		long fee = sc.nextInt();
		// if (validateDoctorInfoSignUp.validateVisitingFee(fee)) {
		doctorInfo.setVisitingFee(fee);
		// } else {
		// code to throw exception
		// }

		doctorInfo.setUserId(doctorId);

		UserFactory uf = new UserFactory();
		DoctorService Service = uf.getDoctorObj();
		Service.addDoctorInfo(doctorInfo);

		DoctorAvailabilityInfo doctorAvailabilityInfo = new DoctorAvailabilityInfo();
		doctorAvailabilityInfo.setDoctorId(doctorId);
		doctorAvailabilityInfo.setFromTime(Time.valueOf("09:00:00"));
		doctorAvailabilityInfo.setToTime(Time.valueOf("05:00:00"));
		doctorAvailabilityInfo.setIsAvialable("Yes");

		Service.addDoctorAvailability(doctorAvailabilityInfo);

		log.info("Registration Completed");
		while (true) {
			log.info("Press 1.To LogIn\nPress 2.To Home ");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				doctorLogIn();
				break;

			case 2:
				MainController.user();
				break;

			default:
				log.info("Invalid Valid Entry");
				break;
			}
		}
	}

	public void manageAppointment() {
		log.info("1.Accept Appointment\n2.Reject Appointment");

		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			acceptAppointment();
			break;

		case 2:
			rejectAppointment();
			break;

		default:
			log.info("invalid entry");
			break;
		}
	}

	public void updateAvailability() {

		UserFactory userFactory = new UserFactory();
		DoctorService service = userFactory.getDoctorObj();
		log.info("Enter your id to update availability");
		int id = sc.nextInt();
		DoctorAvailabilityInfo doctorAvailabilityInfo = new DoctorAvailabilityInfo();

		log.info("Enter the	From Date int yyyy-mm-dd format ");
		String date = sc.next();
		doctorAvailabilityInfo.setFromDate(Date.valueOf(date));

		log.info("Enter the	To Date int yyyy-mm-dd format ");
		String date2 = sc.next();
		doctorAvailabilityInfo.setToDate(Date.valueOf(date2));

		doctorAvailabilityInfo.setIsAvialable("NO");

		service.updateAvailabity(doctorAvailabilityInfo, id);
		log.info("------------------------------------------------");
		log.info("Availability updated status setted has 'NO'");
		log.info("------------------------------------------------");

	}

	public void acceptAppointment() {

		UserFactory userFactory = new UserFactory();
		DoctorService service = userFactory.getDoctorObj();

		log.info("Enter Appointment ID");
		int aId = sc.nextInt();
		service.acceptAppointment(aId);

	}

	public void rejectAppointment() {

		UserFactory userFactory = new UserFactory();
		DoctorService service = userFactory.getDoctorObj();
		log.info("Enter Appointment ID");
		int rId = sc.nextInt();
		service.rejectAppointment(rId);
	}

}

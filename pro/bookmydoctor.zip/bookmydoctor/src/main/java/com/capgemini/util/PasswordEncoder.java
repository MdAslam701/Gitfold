package com.capgemini.util;

import java.util.Scanner;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordEncoder {
	public static String passwordEncoder(String plainPassword) {
		return BCrypt.hashpw("qwerty", BCrypt.gensalt());
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the password to be encoded..");
		String plainPassword = sc.nextLine();
		System.out.println(passwordEncoder(plainPassword));
		sc.close();
	}
	
	

}

package com.capgemini.bookmydoctor.exception;

public class BookMyDoctorException extends RuntimeException {

	String msg = "Invalid Entry";

	public BookMyDoctorException() {
		super();
	}

	public BookMyDoctorException(String msg) {
		super();
		this.msg = msg;
	}
	
	@Override
	public String getMessage() {
		
		return this.msg;
	}

}

package com.capgemini.bookmydoctor.dto;

import lombok.Data;

@Data
public class UserInfo {
	
	private int userId;
	private String userType;
	private String password;
	private long primaryPhoneNo;
	private String emailId;
	private String gender;
	

}
